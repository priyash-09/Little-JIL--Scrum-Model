package laser.littlejil.search.util;

import java.io.File;
import java.util.Set;

import laser.juliette.jul.JarJulFile;
import laser.littlejil.search.AllStepFilter;
import laser.littlejil.search.DFSWorklist;
import laser.lj.ast.structure.Cardinality;
import laser.lj.ast.structure.InterfaceDeclaration;
import laser.lj.ast.structure.StepDeclaration;
import laser.lj.ast.structure.SubstepConnector;
import laser.lj.ast.structure.InterfaceDeclaration.DeclarationKind;
import laser.lj.ast.structure.StepDeclaration.StepKind;


public class LittleJILStatistics 
{		
	public static boolean isChannelDecl(InterfaceDeclaration decl) {
		return (decl.getDeclarationKind() == DeclarationKind.CHANNEL);
	}
	
	public static int getChannelDeclCount(StepDeclaration step) {
		int chnCount = 0;
		
		for (InterfaceDeclaration decl : step.getDeclarations()) {
			if (isChannelDecl(decl)) {
				chnCount++;
			}
		} // end for decl
		
		return chnCount;
	}
	
	public static int getOptionalSubStepCount(StepDeclaration step) {
		int optionalSubStepCount = 0;
		
		for (SubstepConnector substepConn : step.getSubsteps()) {
			//TODO: If the range from lower bound plus one to the upper bound is not empty,
			//      then sub-steps in that range are also optional.
			Cardinality card = substepConn.getCardinality();
			if ((card != null) && (card.getLowerBound() == 0)) {
				optionalSubStepCount++;
			}
		} // end for substepConn
		
		return optionalSubStepCount;
	}
	
	public static boolean isParameterDecl(InterfaceDeclaration decl) {
		DeclarationKind declKind = decl.getDeclarationKind();
		
		return ((declKind == DeclarationKind.IN_OUT_PARAMETER) ||
				(declKind == DeclarationKind.IN_PARAMETER) ||
				(declKind == DeclarationKind.LOCAL_PARAMETER) ||
				(declKind == DeclarationKind.OUT_PARAMETER));
	}
	
	public static int getParameterDeclCount(StepDeclaration step) {
		int paramCount = 0;
		
		for (InterfaceDeclaration decl : step.getDeclarations()) {
			if (isParameterDecl(decl)) {
				paramCount++;
			}
		} // end for decl
		
		//TODO: Exception handler parameter
		
		return paramCount;
	}
	
	public static boolean isChoiceStep(StepDeclaration step) {
		return (step.getStepKind() == StepKind.CHOICE);
	}
	
	public static int getThreadRelatedStepCount(StepDeclaration step, boolean inlined) {
		int threadRelatedStepCount = 0;
		
		if (isChoiceStep(step) || (step.getStepKind() == StepKind.PARALLEL)) {
			if (! inlined) {
				threadRelatedStepCount += step.getSubsteps().size();
			}
			else {
				threadRelatedStepCount += (step.getSubsteps().size() - 1);
			}
		}
		
		int handlerSubStepCount = step.getHandlers().size();
		if (handlerSubStepCount > 0) {
			if (! inlined) {
				threadRelatedStepCount += handlerSubStepCount;
			}
			else {
				threadRelatedStepCount += (handlerSubStepCount - 1);
			}
		}
		
		return threadRelatedStepCount;
	}
	
	public static boolean isLeafStep(StepDeclaration step) {
		return (step.getStepKind() == StepKind.LEAF);
	}
	
	public static boolean mayStepThrowExceptions(StepDeclaration step) {
		for (InterfaceDeclaration decl : step.getDeclarations()) {
			if (decl.getDeclarationKind() == DeclarationKind.EXCEPTION) {
				return true;
			}
		} // end for decl
		
		return false;
	}
	
	public static boolean mayStepHandleExceptions(StepDeclaration step) {
		return (! step.getHandlers().isEmpty());
	}
	
	public static boolean isLeafStepThatMayThrowExceptions(StepDeclaration step) {
		return (isLeafStep(step) && mayStepThrowExceptions(step));
	}
	
	public static boolean isStepThatMayThrowExceptions(StepDeclaration step) {
		return (mayStepThrowExceptions(step));
	}
	
	public static boolean isStepThatMayThrowOrHandleExceptions(StepDeclaration step) {
		return (mayStepThrowExceptions(step) || mayStepHandleExceptions(step));
	}
	
	public static void main (String[] args) throws Exception 
	{
		if (args.length != 2) {
			System.err.println("The JUL file and if inlining will occur must be specified!");
			System.exit(1);
		}
		
		File julFileName = new File(args[0]);
		boolean inlined = Boolean.parseBoolean(args[1]);
		JarJulFile julFile = new JarJulFile(julFileName);
		
		System.out.println("julFile: " + julFileName);
		ResolvedSearch searcher = new ResolvedSearch();
		StepReachability stepInfo = new StepReachability();
		searcher.initialize(julFile, new DFSWorklist());
		searcher.search(new AllStepFilter(), stepInfo);
		Set<StepDeclaration> reachableSteps = stepInfo.getReachableSteps();
		System.out.println("stepDeclCount: " + reachableSteps.size());
		System.out.println("stepDeclRefdCount: " + searcher.getStepDeclarationReferencedCount());
		StepDeclaration maxStepRef = searcher.getMaxStepReference();
		if (maxStepRef != null) {
			int maxStepRefCnt = searcher.getStepReferenceCount(maxStepRef);
			System.out.println("maxStepRef: \"" + maxStepRef.getStepName() + 
					           "\", maxStepRefCnt: " + maxStepRefCnt);
		}
		System.out.println("stepRefCount: " + searcher.getStepReferenceCount());
		
		int threadRelatedStepCount = 1; // The entry point corresponds to the main thread
		int agentDecisionRelatedStepCount = 0;
		int choiceStepCount = 0;
		int choiceSubStepCount = 0;
		int optionalSubStepCount = 0;
		int leafStepCount = 0;
		int leafStepThatMayThrowExceptionsCount = 0;
		int stepThatMayThrowExceptionsCount = 0;
		int stepThatMayThrowOrHandleExceptionsCount = 0;
		int channelDeclCount = 0;
		int parameterDeclCount = 0;
		int dataFlowRelatedStepCount = 0;
		for (StepDeclaration step : reachableSteps) {
			threadRelatedStepCount += getThreadRelatedStepCount(step, inlined);
			if (isChoiceStep(step)) {
				agentDecisionRelatedStepCount++;
				choiceStepCount++;
				choiceSubStepCount += step.getSubsteps().size();
			}
			int tmpOptionalSubStepCount = getOptionalSubStepCount(step);
			if (tmpOptionalSubStepCount > 0) {
				agentDecisionRelatedStepCount += tmpOptionalSubStepCount;
				optionalSubStepCount += tmpOptionalSubStepCount;
			}
			if (isLeafStep(step)) {
				leafStepCount++;
				if (isLeafStepThatMayThrowExceptions(step)) {
					agentDecisionRelatedStepCount++;
					leafStepThatMayThrowExceptionsCount++;
				}
			}
			if (isStepThatMayThrowExceptions(step)) {
				stepThatMayThrowExceptionsCount++;
			}
			if (isStepThatMayThrowOrHandleExceptions(step)) {
				stepThatMayThrowOrHandleExceptionsCount++;
			}
			int tmpChannelDeclCount = getChannelDeclCount(step);
			int tmpParameterDeclCount = getParameterDeclCount(step);
			int tmpArtifactDeclCount = tmpChannelDeclCount + tmpParameterDeclCount;
			channelDeclCount += tmpChannelDeclCount;
			parameterDeclCount += tmpParameterDeclCount;
			if (tmpArtifactDeclCount > 0) {
				dataFlowRelatedStepCount++;
			}
		} // end for step
		System.out.println("Control-flow statistics::");
		System.out.println("threadRelatedStepCount: " + threadRelatedStepCount);
		System.out.println("agentDecisionRelatedStepCount: " + agentDecisionRelatedStepCount);
		System.out.println("choiceStepCount: " + choiceStepCount);
		System.out.println("choiceSubStepCount: " + choiceSubStepCount);
		System.out.println("optionalSubStepCount: " + optionalSubStepCount);
		System.out.println("leafStepCount: " + leafStepCount);
		System.out.println("leafStepThatMayThrowExceptionCount: " + leafStepThatMayThrowExceptionsCount);
		System.out.println("stepThatMayThrowExceptionsCount: " + stepThatMayThrowExceptionsCount);
		System.out.println("stepThatMayThrowOrHandleExceptionsCount: " + stepThatMayThrowOrHandleExceptionsCount);
		System.out.println("Data-flow statistics::");
		System.out.println("channelDeclCount: " + channelDeclCount);
		System.out.println("parameterDeclCount: " + parameterDeclCount);
		System.out.println("dataFlowRelatedStepCount: " + dataFlowRelatedStepCount);
	}
}
