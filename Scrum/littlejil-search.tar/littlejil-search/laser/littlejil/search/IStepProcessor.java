package laser.littlejil.search;

import laser.juliette.jul.JulFile;
import laser.lj.ast.structure.StepDeclaration;


public interface IStepProcessor
{	
	public void setUp (JulFile program);
	
	public void preProcess(StepDeclaration step);
	
	public void postProcess(StepDeclaration step);
	
	public void tearDown();
}
