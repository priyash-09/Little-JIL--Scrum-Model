package laser.littlejil.search;

import laser.lj.ast.structure.StepDeclaration;


public interface IStepFilter
{
	public boolean accept(StepDeclaration step);
}
