package laser.littlejil.search;

import laser.juliette.jul.JulFile;
import laser.lj.ast.structure.StepDeclaration;


public interface IWorklist 
{
	public void initialize (JulFile program);
	
	public void add (StepDeclaration step);
	
	public boolean contains(StepDeclaration step);
	
	public StepDeclaration remove();
	
	public boolean isEmpty();
	
	public int size();
}
