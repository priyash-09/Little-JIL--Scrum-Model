package laser.littlejil.search;

import java.util.Stack;

import laser.juliette.jul.JulFile;
import laser.lj.ast.structure.StepDeclaration;


public class DFSWorklist implements IWorklist
{
	private Stack<StepDeclaration> elements_;
	
	public DFSWorklist() {
		super();
		this.elements_ = new Stack<StepDeclaration>();
	}
	
	public void add(StepDeclaration step) {
		this.elements_.add(step);
	}

	public boolean contains(StepDeclaration step) {
		return this.elements_.contains(step);
	}

	public void initialize(JulFile program) {
		//No-op
	}

	public boolean isEmpty() {
		return this.elements_.isEmpty();
	}

	public StepDeclaration remove() {
		return this.elements_.pop();
	}

	public int size() {
		return this.elements_.size();
	}
}
