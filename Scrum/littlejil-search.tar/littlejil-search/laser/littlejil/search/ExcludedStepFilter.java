package laser.littlejil.search;

import java.util.Set;
import java.util.TreeSet;

import laser.lj.ast.structure.StepDeclaration;


public class ExcludedStepFilter implements IStepFilter 
{
	private Set<String> excludedStepNames_;
	
	
	public ExcludedStepFilter(Set<String> notStepNames) {
		super();
		this.excludedStepNames_ = new TreeSet<String>(notStepNames);
	}
	
	public boolean accept(StepDeclaration step) {
		return (! this.excludedStepNames_.contains(step.getStepName()));
	}
}
