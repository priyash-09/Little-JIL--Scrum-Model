package laser.littlejil.search.util;

import laser.littlejil.search.Search;
import laser.lj.ast.structure.Step;
import laser.lj.ast.structure.StepDeclaration;
import laser.lj.ast.structure.StepReference;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class ResolvedSearch extends Search
{
	protected Map<StepDeclaration,List<StepReference>> stepDeclToRefList_;
	
	
	public ResolvedSearch() {
		super();
		this.stepDeclToRefList_ = new LinkedHashMap<StepDeclaration,List<StepReference>>();
	}
	
	public int getStepDeclarationReferencedCount() {
		return this.stepDeclToRefList_.size();
	}
	
	protected void addStepReference(StepDeclaration targetStepDecl, StepReference targetStepRef) {
		List<StepReference> refList = this.stepDeclToRefList_.get(targetStepDecl);
		
		if (refList == null) {
			refList = new ArrayList<StepReference>();
			this.stepDeclToRefList_.put(targetStepDecl, refList);
		}
		refList.add(targetStepRef);
	}	
	
	public List<StepReference> getStepReferences(StepDeclaration stepDecl) {
		List<StepReference> stepRefs = this.stepDeclToRefList_.get(stepDecl);
		
		if (stepRefs == null) {
			return null;
		}
		else {
			return Collections.unmodifiableList(stepRefs);
		}
	}
	
	public int getStepReferenceCount(StepDeclaration stepDecl) {
		List<StepReference> stepRefs = this.getStepReferences(stepDecl);
		
		if (stepRefs == null) {
			return 0;
		}
		else {
			return stepRefs.size();
		}
	}
	
	public int getStepReferenceCount() {
		int stepRefCnt = 0;
		
		for (StepDeclaration nextStepDecl : this.stepDeclToRefList_.keySet()) {
			stepRefCnt += this.getStepReferenceCount(nextStepDecl);
		} // end for stepDecl
		
		return stepRefCnt;
	}
	
	public StepDeclaration getMaxStepReference() {
		int maxStepRefCnt = -1;
		StepDeclaration maxStepRef = null;
		
		for (StepDeclaration nextStepDecl : this.stepDeclToRefList_.keySet()) {
			int nextStepRefCnt = this.getStepReferenceCount(nextStepDecl);
			
			if (nextStepRefCnt > maxStepRefCnt) {
				maxStepRefCnt = nextStepRefCnt;
				maxStepRef = nextStepDecl;
			}
		} // end for stepDecl
		
		return maxStepRef;
	}
	
	protected StepDeclaration getStepDeclaration(Step targetStep) {
		StepDeclaration targetStepDecl = super.getStepDeclaration(targetStep);
		
		if (targetStep instanceof StepReference) {
			StepReference targetStepRef = (StepReference)targetStep;
			
			this.addStepReference(targetStepDecl, targetStepRef);
		}
		
		return targetStepDecl;
	}
}
