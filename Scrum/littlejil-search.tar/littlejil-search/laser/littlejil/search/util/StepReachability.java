package laser.littlejil.search.util;

import java.io.File;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import laser.juliette.jul.JarJulFile;
import laser.juliette.jul.JulFile;
import laser.littlejil.search.AllStepFilter;
import laser.littlejil.search.DFSWorklist;
import laser.littlejil.search.IStepProcessor;
import laser.littlejil.search.Search;
import laser.lj.ast.structure.Module;
import laser.lj.ast.structure.StepDeclaration;


public class StepReachability implements IStepProcessor
{
	private Map<String, StepDeclaration> reachableSteps_;
	
	
	public StepReachability() {
		super();
		this.reachableSteps_ = new TreeMap<String, StepDeclaration>();
	}

	public Set<String> getReachableStepNames() {
		Set<String> reachableStepNames = new TreeSet<String>();
		reachableStepNames.addAll(this.reachableSteps_.keySet());
		return reachableStepNames;
	}
	
	public StepDeclaration getReachableStep(String stepName) {
		return this.reachableSteps_.get(stepName);
	}
	
	public Set<StepDeclaration> getReachableSteps() {
		Set<StepDeclaration> reachableSteps = new LinkedHashSet<StepDeclaration>();
		reachableSteps.addAll(this.reachableSteps_.values());
		return reachableSteps;
	}
	
	public StepDeclaration removeStepDeclaration(String stepName) {
		return this.reachableSteps_.remove(stepName);
	}
	
	public void postProcess(StepDeclaration step) {
		//No-op
	}

	public void preProcess(StepDeclaration step) {
		this.reachableSteps_.put(step.getStepName(), step);
	}

	public void setUp(JulFile program) {
		//No-op
	}

	public void tearDown() {
		//DEBUG
		System.out.println("StepReachability.tearDown:: The reachable steps are " + this.reachableSteps_);
	}
	
	public static void main (String[] args) throws Exception {
		if (args.length != 1) {
			System.err.println("The JUL file must be specified!");
			System.exit(1);
		}
		
		File julFileName = new File(args[0]);
		JarJulFile julFile = new JarJulFile(julFileName);
		
		System.out.println("julFile: " + julFileName);
		Search searcher = new Search();
		StepReachability stepInfo = new StepReachability();
		searcher.initialize(julFile, new DFSWorklist());
		searcher.search(new AllStepFilter(), stepInfo);
		System.out.println("numberOfSteps: " + stepInfo.getReachableSteps().size());
		int numberOfSteps = 0;
		List<String> moduleNames = julFile.getModuleNames();
		List<Module> modules = julFile.getPath();
		for (int i = 0; i < moduleNames.size(); i++) {
			String currentModuleName = moduleNames.get(i);
			Module currentModule = modules.get(i);
			Search currentSearcher = new Search();
			StepReachability currentStepInfo = new StepReachability();
			currentSearcher.initialize(julFile, currentModule, new DFSWorklist());
			currentSearcher.search(new AllStepFilter(), currentStepInfo);
			int currentNumberOfSteps = currentStepInfo.getReachableSteps().size();
			System.out.println("module " + currentModuleName + ": " + currentNumberOfSteps);
			numberOfSteps += currentNumberOfSteps;
		} // end for currentModule
		System.out.println("numberOfSteps: " + numberOfSteps);
	} // end of main
} // end of StepReachability
