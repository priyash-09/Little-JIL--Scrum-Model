package laser.littlejil.search;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import laser.juliette.jul.EntryPointNotFoundException;
import laser.juliette.jul.JulFile;
import laser.lj.ast.ASTNodeAdapterFactory;
import laser.lj.ast.FactoryFactory;
import laser.lj.ast.NoSuchAdapterForNodeException;
import laser.lj.ast.resolved.ResolutionException;
import laser.lj.ast.structure.Connector;
import laser.lj.ast.structure.HandlerConnector;
import laser.lj.ast.structure.Module;
import laser.lj.ast.structure.ReactionConnector;
import laser.lj.ast.structure.Step;
import laser.lj.ast.structure.StepDeclaration;
import laser.lj.ast.structure.SubstepConnector;


public class Search
{
	protected JulFile program_;
	protected ASTNodeAdapterFactory adapterFactory_;
	protected IWorklist worklist_;
	
	
	public void initialize (JulFile program, IWorklist worklist) {
		this.program_ = program;
		this.adapterFactory_ = FactoryFactory.createASTNodeAdapterFactory();
		this.worklist_ = worklist;
		
		this.worklist_.initialize(program);
		StepDeclaration initialStep = null;
		try {
			initialStep = this.program_.getEntryPoint();
		} catch (EntryPointNotFoundException e) {
			throw new RuntimeException(e);
		}
		this.worklist_.add(initialStep);
	}
	
	public void initialize (JulFile program, Module module, IWorklist worklist) {
		this.program_ = program;
		this.adapterFactory_ = FactoryFactory.createASTNodeAdapterFactory();
		this.worklist_ = worklist;
		
		boolean foundModule = false;
		for (Module nextModule : program.getPath()) {
			if (nextModule == module) {
				foundModule = true;
				break;
			}
		} // end for nextModule
		if (foundModule == false) {
			throw new IllegalArgumentException("Program, " + program + ", does not contain module, " + module + ".");
		}
		
		this.worklist_.initialize(program);
		for (Step initialStep : module.getProcessFragments()) {
			this.worklist_.add(this.getStepDeclaration(initialStep));
		} // end for initialStep
	}
	
	public void search(IStepFilter filter, IStepProcessor processor) {
		processor.setUp(this.program_);
		
		Set<StepDeclaration> visited = new LinkedHashSet<StepDeclaration>();
		while (! this.worklist_.isEmpty()) {
			StepDeclaration parentStep = this.worklist_.remove();
			
			if (! filter.accept(parentStep)) {
				continue;
			}
			else if (visited.contains(parentStep)) {
				continue;
			}
			else {
				visited.add(parentStep);
				
				processor.preProcess(parentStep);

				List<StepDeclaration> childrenSteps = this.getChildrenSteps(parentStep);
				for (StepDeclaration childStep : childrenSteps) {
					if (! visited.contains(childStep)) {
						this.worklist_.add(childStep);
					}
				} // end for
				
				processor.postProcess(parentStep);
			}
		} // end while
		
		processor.tearDown();
	}

	protected List<StepDeclaration> getChildrenSteps(StepDeclaration parentStep) {
		List<StepDeclaration> childrenSteps = new ArrayList<StepDeclaration>();
		
		StepDeclaration preRequisiteStep = 
			this.getTargetStepDeclaration(parentStep.getPrerequisite());
		if (preRequisiteStep != null) {
			childrenSteps.add(preRequisiteStep);
		}
		
		for (SubstepConnector substepConn : parentStep.getSubsteps()) {
			StepDeclaration substep = this.getTargetStepDeclaration(substepConn);
			if (substep != null) {
				childrenSteps.add(substep);
			}
		}
		
		for (HandlerConnector handlerConn : parentStep.getHandlers()) {
			StepDeclaration handler = this.getTargetStepDeclaration(handlerConn);
			if (handler != null) {
				childrenSteps.add(handler);
			}
		}
		
		for (ReactionConnector reactionConn : parentStep.getReactions()) {
			StepDeclaration reaction = this.getTargetStepDeclaration(reactionConn);
			if (reaction != null) {
				childrenSteps.add(reaction);
			}
		}
		
		StepDeclaration postRequisiteStep =
			this.getTargetStepDeclaration(parentStep.getPostrequisite());
		if (postRequisiteStep != null) {
			childrenSteps.add(postRequisiteStep);
		}
		
		return childrenSteps;
	}

	protected StepDeclaration getStepDeclaration(Step targetStep) {
		if (targetStep == null) {
			return null;
		}
		
		laser.lj.ast.resolved.StepDeclaration resolvedTargetStepDecl;
		try {
			resolvedTargetStepDecl = (laser.lj.ast.resolved.StepDeclaration)this.adapterFactory_.wrapAsResolvedNode(targetStep, this.program_.getPath());
			return (StepDeclaration)this.adapterFactory_.wrapAsStructureNode(resolvedTargetStepDecl);
		} catch (NoSuchAdapterForNodeException e) {
			throw new RuntimeException(e);
		} catch (ResolutionException e) {
			throw new RuntimeException(e);
		}
	}
	
	protected StepDeclaration getTargetStepDeclaration(Connector childConn) {
		if (childConn == null) {
			return null;
		}
		
		Step targetStep = childConn.getTarget();
		if (targetStep == null) {
			return null;
		}
		
		return this.getStepDeclaration(targetStep);
	}
}
