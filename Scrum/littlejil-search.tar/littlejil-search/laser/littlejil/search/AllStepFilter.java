package laser.littlejil.search;

import laser.lj.ast.structure.StepDeclaration;


public class AllStepFilter implements IStepFilter {

	public boolean accept(StepDeclaration step) {
		return true;
	}
}
